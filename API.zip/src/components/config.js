// config.js
const config = {
  baseURL: "https://quickmake.graphiglow.in/", // Your baseURL here
};

export default config;
