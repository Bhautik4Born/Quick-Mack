<?php
include 'include/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'] ?? null;
    $module_id = $_POST['module_id'] ?? null;
    $project_id = $_POST['project_id'] ?? null;

    if (!$user_id || !$module_id || (!$project_id && $project_id !== "0")) {
        echo '<script>alert("Please first create a project and write again.");</script>';
        echo '<script>window.location.href = "http://localhost:3000/CreateProject/?projectId='.$project_id.'";</script>';
        exit();
    }

    // Sanitize inputs to prevent SQL injection
    $user_id = mysqli_real_escape_string($con, $user_id);
    $project_id = mysqli_real_escape_string($con, $project_id);

    $insertQuery = "INSERT INTO quickma_ModuleProject (user_id, module_id, project_id) VALUES ('$user_id', '$module_id', '$project_id')";
    $result = mysqli_query($con, $insertQuery);

    if (!$result) {
        echo json_encode(['error' => 'Error inserting data']);
        exit();
    }

    // Fetch existing module_ids from quickma_project
    $selectQuery = "SELECT module_id FROM quickma_project WHERE id = '$project_id'";
    $selectResult = mysqli_query($con, $selectQuery);
    
    if (!$selectResult) {
        echo json_encode(['error' => 'Error fetching data']);
        exit();
    }
    
    $row = mysqli_fetch_assoc($selectResult);
    $existingModuleIds = explode(',', $row['module_id']);

    // Add new module_id if it's not already present
    if (!in_array($module_id, $existingModuleIds)) {
        $existingModuleIds[] = $module_id;

        // Update quickma_project with the updated module_ids
        $updatedModuleIds = implode(',', $existingModuleIds);
        $updateQuery = "UPDATE quickma_project SET module_id = '$updatedModuleIds' WHERE id = '$project_id'";
        $updateResult = mysqli_query($con, $updateQuery);

        if (!$updateResult) {
            echo json_encode(['error' => 'Error updating data']);
            exit();
        }
    }

    echo '<script>alert("Module Add");</script>';
    echo '<script>window.location.href = "http://localhost:3000/CreateProject/?projectId='.$project_id.'&module_id='.$module_id.'";</script>';
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}

?>