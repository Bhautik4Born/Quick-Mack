<?php
$server="localhost";
$username="graphig_QuickMake";
$password="TvOFDI%09@fZ";
$database="graphig_QuickMake";

$con=mysqli_connect($server,$username,$password,$database);

if(!$con)
{
	
	die("Connection Fail....".mysqli_connect_error());
	
}
      date_default_timezone_set('Asia/Kolkata');
    
?>