// For '/module' API
const express = require('express');
const router = express.Router();

module.exports = (db) => {
  router.post('/module', (req, res) => {
    const { user_id, technology_id, module, hours_number, prize } = req.body;
    
    // Check if any required field is empty or missing
    if (!user_id || !technology_id || !module || !hours_number || !prize) {
      return res.status(400).json({ message: 'All fields are required' });
    }
  
    const insertQuery = 'INSERT INTO quickma_module (user_id, technology_id, module, hours_number, prize) VALUES (?, ?, ?, ?, ?)';
    const values = [user_id, technology_id, module, hours_number, prize];
  
    db.query(insertQuery, values, (err, result) => {
      if (err) {
        console.error('Error Adding Module data:', err);
        return res.status(500).json({ message: 'Error Adding Module data' });
      }
      console.log('Data stored successfully!');
      res.json({ message: 'Data stored successfully!' });
    });
  });

  return router;
};
