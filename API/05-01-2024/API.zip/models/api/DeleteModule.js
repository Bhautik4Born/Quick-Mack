const express = require('express');
const router = express.Router();

module.exports = (db) => {
  router.post('/deleteModule', (req, res) => {
    const { module_id } = req.body;

    // Check if module_id is provided
    if (!module_id) {
      return res.json({ message: 'Module ID is required' });
    }

    const deleteQuery = 'DELETE FROM quickma_module WHERE id = ?';
    db.query(deleteQuery, [module_id], (err, result) => {
      if (err) {
        console.error('Error deleting data:', err);
        return res.json({ message: 'Error deleting data' });
      }

      if (result.affectedRows === 0) {
        return res.json({ message: 'Module ID not found' });
      }

      console.log('Module deleted successfully!');
      res.json({ message: 'Module deleted successfully!' });
    });
  });

  return router;
};
