const express = require('express');
const router = express.Router();

module.exports = (db) => {
  router.post('/ModuleProject', (req, res) => {
    const { user_id, module_id } = req.body;

    // Check if user_id and module_id are provided
    if (!user_id || !module_id) {
      return res.json({ error: 'User ID and Module ID are required' });
    }

    const insertQuery = 'INSERT INTO quickma_ModuleProject (user_id, module_id) VALUES (?, ?)';

    db.query(insertQuery, [user_id, module_id], (err, result) => {
      if (err) {
        console.error('Error inserting data:', err);
        return res.json({ error: 'Error inserting data' });
      }

      console.log('Data inserted successfully!');
      res.json({ message: 'Data inserted successfully', affectedRows: result.affectedRows });
    });
  });

  return router;
};
