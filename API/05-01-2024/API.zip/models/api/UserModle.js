const express = require('express');
const router = express.Router();

module.exports = (db) => {
  router.post('/getUserModule', (req, res) => {
    const { user_id } = req.body;

    // Check if user_id is provided
    if (!user_id) {
      return res.json({ error: 'User ID is required' });
    }

    const selectQuery = 'SELECT * FROM quickma_module WHERE user_id = ? ORDER BY id DESC';

    db.query(selectQuery, [user_id], (err, results) => {
      if (err) {
        console.error('Error retrieving data:', err);
        return res.json({ error: 'Error retrieving data' });
      }

      if (results.length === 0) {
        return res.json({ error: 'No records found for the user ID' });
      }

      // Adding sequence number starting from 1 to each record
      const dataWithSequence = results.map((record, index) => ({
        ...record,
        sequence_number: index + 1,
      }));

      console.log('Data retrieved successfully!');
      res.json({
        total_records: results.length,
        data: dataWithSequence,
      });
    });
  });

  return router;
};
