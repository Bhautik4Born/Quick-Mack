const express = require('express');
const router = express.Router();

module.exports = (db) => {
  router.post('/project', (req, res) => {
    const { user_id, project_id } = req.body;

    // Check if user_id is provided
    if (!user_id || !project_id) {
      return res.json({ error: 'User ID and project ID are required' });
    }

    const selectQuery = 'SELECT * FROM quickma_project WHERE user_id = ? AND id = ? ORDER BY id DESC';

    db.query(selectQuery, [user_id, project_id], (err, results) => {
      if (err) {
        console.error('Error retrieving data:', err);
        return res.json({ error: 'Error retrieving data' });
      }

      if (results.length === 0) {
        return res.json({ error: 'No records found for the user ID and project ID' });
      }

      const moduleIds = results.map((record) => record.module_id.split(',')).flat(); // Extract and flatten module IDs

      // Query to fetch prize values from quickma_module table based on module_ids
      const moduleQuery = `SELECT id, prize, module, technology_id, hours_number FROM quickma_module WHERE id IN (${moduleIds.join(',')})`;

      db.query(moduleQuery, (moduleErr, moduleResults) => {
        if (moduleErr) {
          console.error('Error retrieving module data:', moduleErr);
          return res.json({ error: 'Error retrieving module data' });
        }

        // Mapping module prize values to their respective module IDs
        const moduleData = {};
        moduleResults.forEach((moduleRecord) => {
          moduleData[moduleRecord.id] = {
            prize: moduleRecord.prize,
            module: moduleRecord.module,
            technology_id: moduleRecord.technology_id,
            hours_number: moduleRecord.hours_number,
          };
        });

        // Adding sequence number starting from 1 to each record
        const dataWithSequence = results.map((record, index) => ({
          ...record,
          sequence_number: index + 1,
          module_details: record.module_id.split(',').map((moduleId) => moduleData[moduleId]), // Adding module details to each record
        }));

        console.log('Data retrieved successfully!');
        res.json({
          total_records: results.length,
          data: dataWithSequence,
        });
      });
    });
  });

  return router;
};
