const express = require('express');
const router = express.Router();

module.exports = (db) => {
  router.post('/module', (req, res) => {
    const { user_id } = req.body;

    // Check if user_id is provided
    if (!user_id) {
      return res.json({ error: 'User ID is required' });
    }

    const selectQuery = `
    SELECT q.*, GROUP_CONCAT(t.technology) as technology_names
    FROM quickma_module q
    LEFT JOIN technology t ON FIND_IN_SET(t.id, q.technology_id)
    WHERE q.user_id = ?  -- Specify 'user_id' from the 'quickma_module' table
    GROUP BY q.module, q.user_id
    ORDER BY q.module, q.id 
    `;

    db.query(selectQuery, [user_id], (err, results) => {
      if (err) {
        console.error('Error retrieving data:', err);
        return res.json({ error: 'Error retrieving data' });
      }

      if (results.length === 0) {
        return res.json({ error: 'No records found for the user ID' });
      }

      const aggregatedData = [];
      let currentModule = null;
      let totalHours = 0;
      let totalPrize = 0;
      let technologyNames = [];

      for (const record of results) {
        if (record.module !== currentModule) {
          if (currentModule !== null) {
            aggregatedData.push({
              ...results.find((item) => item.module === currentModule),
              hours_number: totalHours.toString(),
              prize: totalPrize.toString(),
              technology_names: [...new Set(technologyNames.split(','))],
            });
          }

          currentModule = record.module;
          totalHours = 0;
          totalPrize = 0;
          technologyNames = '';
        }

        totalHours += parseFloat(record.hours_number);
        totalPrize += parseFloat(record.prize);
        technologyNames = record.technology_names;
      }

      // Push the last module data
      aggregatedData.push({
        ...results.find((item) => item.module === currentModule),
        hours_number: totalHours.toString(),
        prize: totalPrize.toString(),
        technology_names: [...new Set(technologyNames.split(','))],
      });

      console.log('Data retrieved successfully!');
      res.json({
        total_records: aggregatedData.length,
        data: aggregatedData,
      });
    });
  });

  return router;
};
