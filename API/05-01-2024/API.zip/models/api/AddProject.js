// For '/project' API
const express = require('express');
const router = express.Router();

module.exports = (db) => {
  router.post('/project', (req, res) => {
    const { user_id, client_name, project_name, module_id} = req.body;
    
    // Check if any required field is empty or missing
    if (!user_id || !client_name || !project_name || !module_id) {
      return res.status(400).json({ message: 'All fields are required' });
    }
  
    const insertQuery = 'INSERT INTO quickma_project (user_id, client_name, project_name, module_id) VALUES (?, ?, ?, ?)';
    const values = [user_id, client_name, project_name, module_id];
  
    db.query(insertQuery, values, (err, result) => {
      if (err) {
        console.error('Error Adding Module data:', err);
        return res.status(500).json({ message: 'Error Adding Module data' });
      }
      console.log('Data stored successfully!');
       // Get the last inserted ID
      const lastInsertId = result.insertId;
      res.json({ message: 'Data stored successfully!' , project_id: lastInsertId });
    });
  });

  return router;
};
